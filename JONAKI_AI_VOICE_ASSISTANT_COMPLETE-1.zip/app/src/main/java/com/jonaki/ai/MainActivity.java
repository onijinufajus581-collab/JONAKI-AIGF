package com.jonaki.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.animation.ObjectAnimator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView state, orb;
    private static final int REQ = 88;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,11,29));
        getWindow().setNavigationBarColor(Color.rgb(8,11,29));
        makeScreen();
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false); b.setBackground(shape(color, 0, 24));
        return b;
    }

    private void makeScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(24, 28, 24, 24);
        page.setBackgroundColor(Color.rgb(8,11,29));
        setContentView(page);

        TextView brand = label("JONAKI AI", 27, Color.WHITE, true);
        brand.setGravity(Gravity.CENTER);
        page.addView(brand);

        TextView sub = label("VOICE CONTROL • PERSONAL ASSISTANT", 10, 0xFF59E9FF, true);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 5, 0, 20);
        page.addView(sub);

        orb = label("✦", 72, 0xFFECFBFF, true);
        orb.setGravity(Gravity.CENTER);
        orb.setBackground(shape(0xFF261451, 0xFF00E5FF, 180));
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(190,190);
        op.topMargin = 16; op.bottomMargin = 22;
        page.addView(orb, op);
        ObjectAnimator pulse = ObjectAnimator.ofFloat(orb, "alpha", 0.55f, 1f);
        pulse.setDuration(1300); pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.setRepeatMode(ObjectAnimator.REVERSE);
        pulse.setInterpolator(new AccelerateDecelerateInterpolator()); pulse.start();

        state = label("● READY", 14, 0xFF5CF1FF, true);
        state.setGravity(Gravity.CENTER);
        page.addView(state);

        TextView info = label(
            "অ্যাপ চালু করে START LISTENING চাপো। এরপর অন্য অ্যাপে গেলেও নোটিফিকেশনসহ ভয়েস সার্ভিস চলবে। বন্ধ করতে STOP চাপো।",
            14, 0xFFD7D9EA, false);
        info.setGravity(Gravity.CENTER);
        info.setPadding(8, 20, 8, 22);
        page.addView(info);

        Button start = button("🎙  START LISTENING", 0xFF6941D8);
        Button stop = button("■  STOP LISTENING", 0xFFB83255);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 58);
        bp.bottomMargin = 12;
        page.addView(start, bp);
        page.addView(stop, new LinearLayout.LayoutParams(-1,58));

        TextView note = label(
            "Voice recognition uses your phone's speech service. A female voice is used only if your Android TTS engine has one installed. App installs, messages and social posts require your confirmation.",
            11, 0xFF9FA5C4, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(4, 20, 4, 0);
        page.addView(note);

        start.setOnClickListener(v -> requestAndStart());
        stop.setOnClickListener(v -> stopAssistant());
    }

    private void requestAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ + 1);
            return;
        }
        startServiceNow();
    }

    private void startServiceNow() {
        Intent i = new Intent(this, VoiceAssistantService.class);
        i.setAction(VoiceAssistantService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        state.setText("● LISTENING — notification active");
        Toast.makeText(this, "JONAKI AI listening started", Toast.LENGTH_SHORT).show();
    }

    private void stopAssistant() {
        Intent i = new Intent(this, VoiceAssistantService.class);
        i.setAction(VoiceAssistantService.ACTION_STOP);
        startService(i);
        state.setText("● STOPPED");
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if ((r == REQ || r == REQ + 1) && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) {
            if (r == REQ) requestAndStart(); else startServiceNow();
        } else if (r == REQ) {
            Toast.makeText(this, "Microphone permission is required for voice control.", Toast.LENGTH_LONG).show();
        }
    }
}
