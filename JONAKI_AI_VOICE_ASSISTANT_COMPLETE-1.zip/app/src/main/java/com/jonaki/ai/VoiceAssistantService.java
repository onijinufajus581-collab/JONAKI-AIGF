package com.jonaki.ai;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class VoiceAssistantService extends Service implements RecognitionListener {
    public static final String ACTION_START = "com.jonaki.ai.START";
    public static final String ACTION_STOP = "com.jonaki.ai.STOP";
    private static final String CHANNEL = "jonaki_voice_channel";
    private static final int NOTIFICATION_ID = 741;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean running = false;
    private boolean speaking = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("bn", "BD"));
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(new Locale("en", "US"));
                }
                // Android TTS voice gender depends on installed voice data and engine.
            }
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopAssistant();
            return START_NOT_STICKY;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        if (!running) {
            running = true;
            beginListening();
        }
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "JONAKI AI Voice", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while voice assistant is listening");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JONAKI AI is listening")
            .setContentText("Tap STOP in the app to turn off voice listening.")
            .setContentIntent(pi).setOngoing(true).build();
    }

    private void beginListening() {
        if (!running || speaking) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("এই ফোনে voice recognition service পাওয়া যাচ্ছে না।");
            return;
        }
        try {
            if (recognizer != null) { recognizer.destroy(); recognizer = null; }
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(this);
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            recognizer.startListening(i);
        } catch (Exception e) {
            say("শোনা শুরু করা যাচ্ছে না।");
        }
    }

    private void restartListening() {
        if (running && !speaking) {
            if (recognizer != null) {
                try { recognizer.destroy(); } catch (Exception ignored) {}
                recognizer = null;
            }
            new android.os.Handler(getMainLooper()).postDelayed(this::beginListening, 650);
        }
    }

    private void handleCommand(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty()) { restartListening(); return; }

        if (has(s, "stop listening", "স্টপ", "বন্ধ হও", "শোনা বন্ধ", "থেমে যাও")) {
            say("ঠিক আছে, আমি বন্ধ হচ্ছি।");
            new android.os.Handler(getMainLooper()).postDelayed(this::stopAssistant, 1000);
            return;
        }
        if (has(s, "youtube", "ইউটিউব")) {
            String query = afterKeyword(raw, "search", "সার্চ", "খুঁজে", "গান", "ভিডিও");
            if (!query.isEmpty() && has(s, "search", "সার্চ", "খুঁজে", "গান", "ভিডিও")) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                safeStart(i);
                say("ইউটিউবে " + query + " সার্চ খুলে দিচ্ছি।");
            } else {
                launchPackage("com.google.android.youtube", "YouTube");
                say("YouTube খুলে দিচ্ছি।");
            }
            return;
        }
        if (has(s, "play store", "প্লে স্টোর")) {
            String query = afterKeyword(raw, "search", "সার্চ", "খুঁজে", "ইনস্টল", "install");
            if (!query.isEmpty()) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(query) + "&c=apps"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                safeStart(i);
                say(query + " অ্যাপের Play Store পেজ খুলছি। ইনস্টল তোমাকে নিশ্চিত করতে হবে।");
            } else {
                launchPackage("com.android.vending", "Play Store");
                say("Play Store খুলে দিচ্ছি।");
            }
            return;
        }
        if (has(s, "whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটসঅ্যাপ")) {
            launchPackage("com.whatsapp", "WhatsApp");
            say("WhatsApp খুলে দিচ্ছি। কাকে মেসেজ পাঠাবে বলো, পাঠানোর আগে তোমার অনুমতি লাগবে।");
            return;
        }
        if (has(s, "tiktok", "টিকটক")) {
            launchFirst(new String[]{"com.zhiliaoapp.musically", "com.ss.android.ugc.trill"}, "TikTok");
            say("TikTok খুলে দিচ্ছি। ভিডিও পোস্ট করার আগে তুমি নিজে দেখে নিশ্চিত করবে।");
            return;
        }
        if (has(s, "open settings", "সেটিংস খোলো", "সেটিংস ওপেন")) {
            Intent i = new Intent(android.provider.Settings.ACTION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); safeStart(i);
            say("Settings খুলে দিচ্ছি।"); return;
        }
        if (has(s, "time", "সময়", "সময়")) {
            String now = new java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new java.util.Date());
            say("এখন সময় " + now); return;
        }
        say("আমি এই কমান্ডটি এখনো শিখিনি। YouTube, Play Store, WhatsApp বা TikTok খোলার কমান্ড দিতে পারো।");
    }

    private boolean has(String s, String... words) {
        for (String w : words) if (s.contains(w.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private String afterKeyword(String original, String... keys) {
        String lower = original.toLowerCase(Locale.ROOT);
        int best = -1, len = 0;
        for (String k : keys) {
            int p = lower.indexOf(k.toLowerCase(Locale.ROOT));
            if (p >= 0 && (best < 0 || p < best)) { best = p; len = k.length(); }
        }
        if (best < 0) return "";
        String out = original.substring(best + len).trim();
        out = out.replaceFirst("^[\\s:：,，]+", "").trim();
        return out;
    }

    private void launchPackage(String pkg, String name) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { say(name + " ইনস্টল করা নেই।"); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        } catch (Exception e) { say(name + " খোলা যাচ্ছে না।"); }
    }

    private void launchFirst(String[] packages, String name) {
        for (String p : packages) {
            Intent i = getPackageManager().getLaunchIntentForPackage(p);
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); safeStart(i); return; }
        }
        say(name + " ইনস্টল করা নেই।");
    }

    private void safeStart(Intent i) {
        try { startActivity(i); } catch (Exception e) { say("এই কাজটি করা যাচ্ছে না।"); }
    }

    private void say(String words) {
        if (tts == null) { restartListening(); return; }
        speaking = true;
        tts.speak(words, TextToSpeech.QUEUE_FLUSH, null, "jonaki_voice");
        new android.os.Handler(getMainLooper()).postDelayed(() -> {
            speaking = false;
            restartListening();
        }, Math.max(1800, words.length() * 95L));
    }

    private void stopAssistant() {
        running = false;
        speaking = false;
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); recognizer = null; }
        if (tts != null) tts.stop();
        stopForeground(true);
        stopSelf();
    }

    @Override public void onReadyForSpeech(Bundle p) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float rms) {}
    @Override public void onBufferReceived(byte[] b) {}
    @Override public void onEndOfSpeech() {}
    @Override public void onError(int error) { restartListening(); }
    @Override public void onResults(Bundle b) {
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (r != null && !r.isEmpty()) handleCommand(r.get(0)); else restartListening();
    }
    @Override public void onPartialResults(Bundle b) {}
    @Override public void onEvent(int event, Bundle b) {}

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        running = false;
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
